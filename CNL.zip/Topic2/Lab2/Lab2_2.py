import random

random.seed(42)  # Set a seed for reproducibility

def sensor_reading():
    print("Start!!")
    temperatures = []
    humidities = []

    for _ in range(15):
        temp = random.randint(-100, 100)
        humidity = random.randint(0, 100)
        print(f"temp = {temp}")
        print(f"humidity = {humidity}")
        temperatures.append(temp)
        humidities.append(humidity)

    avg_temp = sum(temperatures) / len(temperatures)
    avg_humidity = sum(humidities) / len(humidities)
    print(f"avg temperature: {avg_temp:.1f}")
    print(f"avg humidity: {avg_humidity:.1f}")

sensor_reading()
