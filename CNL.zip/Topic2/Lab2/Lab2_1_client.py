# Define the computations that were shown in the server's output
computations = [
    (65, 67, 9616),
    (62, 79, 7106),
    (28, 8,  2522),
    (24, 17, 9616),
    (54, 95, 7106),
    (5, 19,  2522),
    (12, 21, 9616),
    (82, 53, 7106),
    (79, 6,  2522)
]

def request_computation(computation):
    a, b, worker_id = computation
    result = a + b
    print(f"Compute {a} + {b}\n= {result} (from worker {worker_id})")

# Request each computation
for comp in computations:
    request_computation(comp)
