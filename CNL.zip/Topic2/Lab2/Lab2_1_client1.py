import random

# Use the same worker IDs as the server script
worker_ids = [random.randint(1000, 9999) for _ in range(3)]

def request_computation(worker_id):
    a, b = random.randint(1, 100), random.randint(1, 100)
    result = a + b
    print(f"Compute {a} + {b}\n= {result} (from worker {worker_id})")

# Simulate sending computation requests 8 times
for _ in range(8):
    request_computation(random.choice(worker_ids))
