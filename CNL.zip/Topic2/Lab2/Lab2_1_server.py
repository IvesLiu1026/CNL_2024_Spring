import random

worker_ids = random.randint(1000, 9999)

def start_server(worker_id):
    print(f"Worker {worker_id} is running ...")
    for _ in range(3):
        a, b = random.randint(1, 100), random.randint(1, 100)
        print(f"Compute {a} + {b} and send response")


start_server(worker_ids)
