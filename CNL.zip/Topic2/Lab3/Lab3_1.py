# -*- coding: utf-8 -*-
from flask import Flask, render_template

app = Flask(__name__, template_folder = 'templates')

@app.route('/')

def index():
    ID = 110511184
    return render_template('index.html', ID = 110511184)

if __name__ == '__main__':
    app.run(host = '172.20.10.10', port = 9808, debug = False)