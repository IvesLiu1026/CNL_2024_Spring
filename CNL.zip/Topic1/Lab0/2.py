def min_average_index(nums):
    n = len(nums)
    prefix_sum = [0] * n

    prefix_sum[0] = nums[0]

    for i in range(1, n):
        prefix_sum[i] = prefix_sum[i - 1] + nums[i]

    min_index = 0
    min_diff = abs((prefix_sum[0] / 1) - (prefix_sum[n - 1] / (n - 1))) if n > 1 else 0

    for i in range(1, n - 1):
        prefix_avg = prefix_sum[i] / (i + 1)
        suffix_avg = (prefix_sum[n - 1] - prefix_sum[i]) / (n - i - 1) if (n - i - 1) != 0 else 0
        diff = abs(prefix_avg - suffix_avg)

        if diff < min_diff:
            min_diff = diff
            min_index = i

    return min_index

num_cases = int(input())
results = []

for _ in range(num_cases):
    data = list(map(int, input().split()))
    nums = data[1:]
    result = min_average_index(nums)
    results.append(result)

print(*results, sep="\n")
