def min_coins(coins, amount):
    dp = [float('inf')] * (amount + 1)
    dp[0] = 0

    for coin in coins:
        for i in range(coin, amount + 1):
            dp[i] = min(dp[i], dp[i - coin] + 1)

    return dp[amount]

num_cases = int(input())
results = []

for _ in range(num_cases):
    num_coins, target_amount = map(int, input().split())
    coin_denominations = list(map(int, input().split()))
    result = min_coins(coin_denominations, target_amount)
    results.append(result)

for result in results:
    print(result)