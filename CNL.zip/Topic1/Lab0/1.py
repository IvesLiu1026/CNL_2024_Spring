def luhn_algorithm(card_number):
    card_number = card_number.replace(" ", "")
    if len(card_number) != 16:
        return "Invalid"
    
    digits = [int(digit) for digit in card_number]
    for i in range(14, -1, -2):
        digits[i] = (digits[i] * 2) % 10 + digits[i] * 2 // 10
    
    total = sum(digits)
    return "Valid" if total % 10 == 0 else "Invalid"

N = int(input())
results = []

for _ in range(N):
    card_number = input()
    result = luhn_algorithm(card_number)
    results.append(result)

for result in results:
    print(result)