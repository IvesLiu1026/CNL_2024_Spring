#!/usr/bin/env python
import RPi.GPIO as GPIO
import time
import sys
import Adafruit_DHT

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)
LED_PIN = 12
GPIO.setup(LED_PIN, GPIO.OUT)

# Parse command line parameters.
sensor_args = { '11': Adafruit_DHT.DHT11,
                '22': Adafruit_DHT.DHT22,
                '2302': Adafruit_DHT.AM2302 }
if len(sys.argv) == 3 and sys.argv[1] in sensor_args:
    sensor = sensor_args[sys.argv[1]]
    pin = sys.argv[2]
else:
    print('Usage: sudo ./Adafruit_DHT.py [11|22|2302] <GPIO pin number>')
    print('Example: sudo ./Adafruit_DHT.py 2302 4 - Read from an AM2302 connected to GPIO pin #4')
    sys.exit(1)
    
humidity, temperature = Adafruit_DHT.read_retry(sensor, pin)

v = 331 + 0.6 * temperature
TRIG = 16
ECHO = 18

print '1'
GPIO.setmode(GPIO.BOARD)
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)
GPIO.output(TRIG, GPIO.LOW)
def measure():
    GPIO.output(TRIG, GPIO.HIGH)
    time.sleep(0.00001)
    GPIO.output(TRIG, GPIO.LOW)
    pulse_start = 0
    pulse_end = 0
    while GPIO.input(ECHO) == GPIO.LOW:
        pulse_start = time.time()
    while GPIO.input(ECHO) == GPIO.HIGH:
        pulse_end = time.time()
    
    t = pulse_end - pulse_start
    d = t * v
    d = d / 2
    return d * 100

    
while True:
    print("====================")
    print("Temp: {0:0.1f}*C".format(temperature))
    print("V = 331 + 0.6 * {0:0.1f}".format(temperature))
    print(" = {0:0.1f}".format(v))
    print("Distance: {0:0.1f}cm".format(measure()))
    
    if measure() < 10:
        GPIO.output(LED_PIN, GPIO.HIGH)
    elif measure() > 10 and measure() < 20:
        GPIO.output(LED_PIN, GPIO.HIGH)
        time.sleep(1)
        GPIO.output(LED_PIN, GPIO.LOW)
        time.sleep(1)
    else:
        GPIO.output(LED_PIN, GPIO.LOW)
    
GPIO.cleanup()