#!/usr/bin/env python
import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BOARD)
LED_PIN = 12
GPIO.setup(LED_PIN, GPIO.OUT)

# Define the timing for dot, dash, and spaces in seconds
dot_duration = 0.1
dash_duration = 0.3
letter_space_duration = 0.3
word_space_duration = 0.7

# Morse code for SOS
sos_morse = "... --- ..."

try:
    while True:
        for char in sos_morse:
            if char == ".":
                print("LED is on (dot)")
                GPIO.output(LED_PIN, GPIO.HIGH)
                time.sleep(dot_duration)
                print("LED is off (dot)")
                GPIO.output(LED_PIN, GPIO.LOW)
                time.sleep(dot_duration)
            elif char == "-":
                print("LED is on (dash)")
                GPIO.output(LED_PIN, GPIO.HIGH)
                time.sleep(dash_duration)
                print("LED is off (dash)")
                GPIO.output(LED_PIN, GPIO.LOW)
                time.sleep(dot_duration)
            elif char == " ":
                print("Space between letters")
                time.sleep(letter_space_duration)
        print("Space between words")
        time.sleep(word_space_duration)

except KeyboardInterrupt:
    GPIO.cleanup()
