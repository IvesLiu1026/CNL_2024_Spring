# Import the necessary module from the pybluez library.
import bluetooth

# Create a new Bluetooth socket using the RFCOMM protocol.
server_sock = bluetooth.BluetoothSocket(bluetooth.RFCOMM)

# Set the port number to 2.
port = 2

# Bind the socket to a specific Bluetooth address and port.
# The given Bluetooth address ("B8:27:EB:E3:6F:31") is 
# likely the MAC address of the device this script runs on.
server_sock.bind(("B8:27:EB:E3:6F:31", port))

# Set the socket to listen mode with a backlog of 1, 
# which means it can queue up to 1 connection request before rejecting new ones.
server_sock.listen(1)

# Wait and accept an incoming connection request.
# The function blocks until a connection is made.
client_sock, address = server_sock.accept()

# Print the address of the device that connected.
print("Accepted connection from ", address)

# Receive up to 1024 bytes of data from the connected device.
data = client_sock.recv(1024)

# Print the received data.
print("received [%s]" % data)

# Close the client and server sockets.
client_sock.close()
server_sock.close()
