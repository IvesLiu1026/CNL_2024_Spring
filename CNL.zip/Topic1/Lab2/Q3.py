import bluetooth as bt

nearby_devices = bt.discover_devices()

for bdaddr in nearby_devices:
    print(bdaddr)
    print(bt.lookup_name( bdaddr ))