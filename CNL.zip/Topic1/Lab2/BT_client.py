import bluetooth

# Setting bluetooth address of the server and port number
bd_addr = "B8:27:EB:5A:B3:DD"  
port = 2

# Creating a socket and connecting to the server
sock = bluetooth.BluetoothSocket( bluetooth.RFCOMM )
sock.connect((bd_addr, port))

# Sending a message to the server
sock.send("hello!!")

sock.close()