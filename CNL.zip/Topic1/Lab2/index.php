<?php
    header("Content-Type:text/html; charset=utf-8");
    /* Temp -> server */
    // ex: curl -d "sensor=1&Temp28.9" http://IP_addr
    $Temperature=$_POST[Temp];
    $SensorID=$_POST[sensor];

    echo 'Temperature:'.$Temperature. “\n”;
    
    if ($SensorID==1) {
    $fp = fopen('/home/pi/www-data/temp.txt', 'w');
    fwrite($fp, $Temperature);
    fclose($fp);
}
?>