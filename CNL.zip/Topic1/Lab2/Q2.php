<?php
    header("Content-Type:text/html; charset=utf-8");
    /* Temp -> server */
    // ex: curl -d "sensor=1&Temp28.9" http://IP_addr
    
    // Retrieving the Temperature, Humidity, SensorID, Month, and Day from the POST data.
    $Temp = $_POST['Temp'];
    $Humi = $_POST['Humi'];
    $SensorID = $_POST['SensorID'];
    $Month = $_POST['Month'];
    $Day = $_POST['Day'];

    // Echoing out the Month, Day, SensorID, Temperature, and Humidity for confirmation or debugging.
    echo 'Month:' . $Month . "\n";
    echo 'Day:' . $Day . "\n";
    echo 'Sensor:' . $SensorID . "\n";
    echo 'Temperature:' . $Temp . "\n";
    echo 'Humidity:' . $Humi . "\n";

    // If the SensorID is 1
    if($SensorID == 1){
        // Opening files to save the temperature, humidity, month, and day data for SensorID 1.
        // Writing the temperature data to the file.
        $fp = fopen('/home/pi/www-data/temp_' . $SensorID . '.txt', 'w');
        fwrite($fp, $Temp);
        fclose($fp);

        // Writing the humidity data to the file.
        $fp = fopen('/home/pi/www-data/humi_' . $SensorID . '.txt', 'w');
        fwrite($fp, $Humi);
        fclose($fp);

        // Writing the month data to the file.
        $fp = fopen('/home/pi/www-data/month_' . $SensorID . '.txt', 'w');
        fwrite($fp, $Month);
        fclose($fp);

        // Writing the day data to the file.
        $fp = fopen('/home/pi/www-data/day_' . $SensorID . '.txt', 'w');
        fwrite($fp, $Day);
        fclose($fp);
    }

    // If the SensorID is 2 (This block is the same as above but for SensorID 2)
    if($SensorID == 2){
        // The code here is similar to the block for SensorID 1, but writes data specific to SensorID 2.
        $fp = fopen('/home/pi/www-data/temp_' . $SensorID . '.txt', 'w');
        fwrite($fp, $Temp);
        fclose($fp);

        $fp = fopen('/home/pi/www-data/humi_' . $SensorID . '.txt', 'w');
        fwrite($fp, $Humi);
        fclose($fp);

        $fp = fopen('/home/pi/www-data/month_' . $SensorID . '.txt', 'w');
        fwrite($fp, $Month);
        fclose($fp);

        $fp = fopen('/home/pi/www-data/day_' . $SensorID . '.txt', 'w');
        fwrite($fp, $Day);
        fclose($fp);
    }
?>