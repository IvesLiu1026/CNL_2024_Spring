<?php
    header("Content-Type:text/html; charset=utf-8");
    /* Temp -> server */
    // ex: curl -d "sensor=1&Temp28.9" http://IP_addr

    // Getting the Temperature, SensorID, and Humidity from the POST data.
    $Temperature = $_POST['T'];
    $SensorID = $_POST['S'];
    $Humidity = $_POST['H'];

    // Echoing out the SensorID, Temperature, and Humidity for confirmation or debugging.
    echo 'SensorID:' . $SensorID . "\n";
    echo 'Temperature:' . $Temperature . "\n";
    echo 'Humidity:' . $Humidity . "\n";

    // If the SensorID is 1
    if ($SensorID == 1) {
        // Opening a file to write the temperature data for SensorID 1.
        $fp = fopen('/home/pi/www-data/temp_' . $SensorID . '.txt', 'w');
        // Writing the temperature data to the file.
        fwrite($fp, $Temperature);
        // Closing the file.
        fclose($fp);

        // Opening a file to write the humidity data for SensorID 1.
        $fp = fopen('/home/pi/www-data/humi_' . $SensorID . '.txt', 'w');
        // Writing the humidity data to the file.
        fwrite($fp, $Humidity);
        // Closing the file.
        fclose($fp);
    }

    // If the SensorID is 2 (This block is essentially the same as the one above but for SensorID 2)
    if ($SensorID == 2) {
        $fp = fopen('/home/pi/www-data/temp_' . $SensorID . '.txt', 'w');
        fwrite($fp, $Temperature);
        fclose($fp);

        $fp = fopen('/home/pi/www-data/humi_' . $SensorID . '.txt', 'w');
        fwrite($fp, $Humidity);
        fclose($fp);
    }

?>