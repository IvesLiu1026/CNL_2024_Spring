#!/usr/bin/env python
import RPi.GPIO as GPIO
import time
# import sys, select 
import sys, select
import socket

# connect to server
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(("192.168.168.27", 8001))

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)
LED_PIN = 12
GPIO.setup(LED_PIN, GPIO.OUT)

v = 343
TRIG = 16
ECHO = 18

print '1'
GPIO.setmode(GPIO.BOARD)
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)
GPIO.output(TRIG, GPIO.LOW)
def measure():
    GPIO.output(TRIG, GPIO.HIGH)
    time.sleep(0.00001)
    GPIO.output(TRIG, GPIO.LOW)
    pulse_start = 0
    pulse_end = 0
    while GPIO.input(ECHO) == GPIO.LOW:
        pulse_start = time.time()
    while GPIO.input(ECHO) == GPIO.HIGH:
        pulse_end = time.time()
    
    t = pulse_end - pulse_start
    d = t * v
    d = d / 2
    return d * 100

while(1):
    i, o, e = select.select([sys.stdin], [], [], 3)
    if (i):
        a = sys.stdin.readline().strip()
        print(a, type(a))
        client.sendall(a)
    else:
        print("Nothing")
    
    d = measure()
    if d > 10 and d < 20:
        for i in xrange(10):
            GPIO.output(LED_PIN, GPIO.HIGH)
            time.sleep(0.1)
            GPIO.output(LED_PIN, GPIO.LOW)
            time.sleep(0.1)
            i += 1
    elif d < 10:
        GPIO.output(LED_PIN, GPIO.HIGH)
        stop = 's'
        client.sendall(stop)
    else:
        GPIO.output(LED_PIN, GPIO.LOW)
    print(d)   
    time.sleep(1)
GPIO.cleanup()