package com.example.a110511184_lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    // Declaration of variables
    int randNum=0 ;
    int history=999;
    int min=1;
    int max=50;
    int count=0;

    EditText input;
    Button restart;
    Button sent;
    TextView guess ;
    TextView hint ;
    TextView best ;
    Button replay;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2); // Set the content view to the second activity layout

        // Retrieve data passed from MainActivity
        Bundle bundle = this.getIntent().getExtras();
        String idnum = (String)bundle.getString("number");
        String idname = (String)bundle.getString("name");

        // Initialize UI elements
        input = (EditText) findViewById(R.id.entertext);
        restart = (Button) findViewById(R.id.restartbutton);
        sent = (Button) findViewById(R.id.sentbutton);
        guess = (TextView) findViewById(R.id.guesstext);
        hint = (TextView) findViewById(R.id.hinttext);
        best = (TextView) findViewById(R.id.besttext);
        replay = (Button) findViewById(R.id.replay);

        // Random number generation for the guessing game
        randNum =(int)(Math.random()*50 + 1);

        // OnClickListener for the 'sent' button
        sent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int in = Integer.parseInt(input.getText().toString());

                if (in <= max && in >= min){
                    if (in > randNum){
                        max = in ;
                        count = count + 1 ;
                        hint.setText("請輸入"+min+"~"+max+"的數字");
                        guess.setText("猜測次數:"+count);
                    }else if (in < randNum){
                        min = in ;
                        count = count + 1;
                        hint.setText("請輸入"+min+"~"+max+"的數字");
                        guess.setText("猜測次數:"+count);

                    }else if (in == randNum){
                        count = count + 1 ;
                        guess.setText("猜測次數"+count);
                        hint.setText("Bingo!");
                        if (count < history){
                            history = count ;
                            best.setText("最佳紀錄:"+history);
                        }
                    }
                }else{
                    hint.setText("請輸入"+min+"~"+max+"的數字,請輸入正常值");
                    count = count + 1 ;
                    guess.setText("猜測次數"+count);
                }

            }
        });

        // OnClickListener for the 'restart' button
        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                count = 0 ;
                hint.setText("請輸入1~50的數字");
                guess.setText("猜測次數:"+count);
                randNum =(int)(Math.random()*50 + 1);
                min = 1 ;
                max = 50 ;
            }
        });


        // OnClickListener for the 'replay' button to start MainActivity3
        replay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setClass(MainActivity2.this,MainActivity3.class);
                Bundle bundle = new Bundle();
                bundle.putString("number",idnum);
                bundle.putString("name",idname);
                bundle.putInt("best",history);
                intent.putExtras(bundle);
                startActivity(intent);  // Start MainActivity3
            }
        });


    }
}
