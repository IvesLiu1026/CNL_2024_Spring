package com.example.a110511184_lab2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText editname;
    EditText editnum;
    Button buttonstart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Set the content view to the main activity layout

        // Initialize UI elements
        editname = (EditText) findViewById(R.id.editname);
        editnum = (EditText) findViewById(R.id.editnum);
        buttonstart = (Button) findViewById(R.id.buttonstart);

        // Set an OnClickListener for the start button
        buttonstart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create an Intent to start MainActivity2
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                // Bundle to pass data to MainActivity2
                Bundle bundle = new Bundle();
                bundle.putString("number", editnum.getText().toString());
                bundle.putString("name", editname.getText().toString());
                intent.putExtras(bundle);
                startActivity(intent); // Start MainActivity2
            }
        });
    }
}
