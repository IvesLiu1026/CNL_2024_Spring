# Importing tkinter package and aliasing it as tk
import tkinter as tk
# Importing messagebox from tkinter to avoid 'module tkinter has no attribute messagebox' error
from tkinter import messagebox

# Function to create the Tic-Tac-Toe grid
def create_board():
    # Using a nested for loop to create the 3x3 grid
    for i in range(3):
        for j in range(3):
            # Creating Button widgets on the main window for player1 and player2 to click
            # The command lambda row=i, col=j: handle_click(row, col) specifies the function to call when the Button is clicked
            button = tk.Button(window, text="", font=("Arial", 50), height=2, width=6, command=lambda row=i, col=j: handle_click(row, col))
            # To set a specific row & column for the Button, add the following line
            button.grid(row=i, column=j, sticky="nsew")
            # Setting the background color of the grid cells to white
            button.config(bg='white')

# Function called when a Button is clicked
def handle_click(row, col):
    # Using global keyword to access cur_player and board variables from the main function
    global cur_player
    global board
    # Check if the cell has already been clicked, if so, do nothing to avoid accidental clicks
    if board[row][col] == 0:
        # If the current player is player1
        if cur_player == 1:
            # Record which player clicked the cell
            board[row][col] = 1
            # Switch to player2 for the next turn
            cur_player = 2
            # Setting text on the specific cell
            button = window.grid_slaves(row=row, column=col)[0]
            # Change the text in the cell to "O"
            button.config(text="O")
        # If the current player is player2
        else:
            board[row][col] = 2
            cur_player = 1
            button = window.grid_slaves(row=row, column=col)[0]
            # Change the text in the cell to "X"
            button.config(text="X")

        # Check if someone has won the game or if the game has ended in a tie
        check_winner()

# Function to check the current game status
def check_winner():
    global board
    # Count of clicked cells
    cnt = 0
    # Variable to store the winner
    winner = None
    # Record the winning path to help display the winning line
    winner_path = 0
    # Count clicked cells to determine if the game is a tie
    for i in range(3):
        for j in range(3):
            if board[i][j] != 0:
                cnt += 1
    # If all cells are clicked, it's a tie unless the last click results in a win
    if cnt == 9:
        winner = 3  # Tie

    # Check for winning lines in rows
    for i in range(3):
        if board[i][0] == board[i][1] == board[i][2] != 0:
            winner_path = i + 1
            winner = 1 if board[i][0] == 1 else 2

    # Check for winning lines in columns
    for j in range(3):
        if board[0][j] == board[1][j] == board[2][j] != 0:
            winner_path = j + 4
            winner = 1 if board[0][j] == 1 else 2

    # Check diagonals for winning lines
    if board[0][0] == board[1][1] == board[2][2] != 0:
        winner_path = 7
        winner = 1 if board[0][0] == 1 else 2
    elif board[0][2] == board[1][1] == board[2][0] != 0:
        winner_path = 8
        winner = 1 if board[0][2] == 1 else 2
    
    # Call declare_winner if there's a winner
    if winner:
        declare_winner(winner, winner_path)

# Function to declare the winner and show the result
def declare_winner(winner, winner_path):
    if winner == 3:  # Tie
        # Set all cells to red color
        for i in range(3):
            for j in range(3):
                button = window.grid_slaves(row=i, column=j)[0]
                button.config(bg='red')
        # Ask user if they want to restart the game
        ans = tk.messagebox.askyesno(title="Game Over", message="It's a tie! Do you want to restart the game?")
    else:
        # Color the winning line green
        # ... [Code for coloring the winning line] ...

        # Display a message for the winner and ask if they want to restart the game
        message = "Player 1 wins!" if winner == 1 else "Player 2 wins!"
        ans = tk.messagebox.askyesno(title="Game Over", message=message + " Do you want to restart the game?")

    # Restart the game if 'Yes' is selected, otherwise close the window
    if ans:
        global board
        board = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
        for i in range(3):
            for j in range(3):
                button = window.grid_slaves(row=i, column=j)[0]
                button.config(text="", bg='white')
        global cur_player
        cur_player = 1
    else:
        window.destroy()

# Main window
window = tk.Tk()
window.title('Lab3 Tic-Tac-Toe')

# Create the Tic-Tac-Toe grid
create_board()

# Initialize the board and current player
board = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
cur_player = 1

# Start the main loop of the Tkinter window
window.mainloop()
