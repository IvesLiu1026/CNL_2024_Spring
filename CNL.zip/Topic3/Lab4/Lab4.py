# Import tkinter package and alias it as tk
import tkinter as tk

# Set the default display of the calculator to 0 on frame f1
def SetValue():
    # Setting the text display on frame f1
    # Using textvariable instead of text, as the display updates continuously with user input
    tk.Label(f1, textvariable=var, height=3).grid(column=0, row=3)
    # Set the default display string to '0'
    var.set('0')

    return

# When a button on frame f2 is pressed, update the display string on frame f1
def Click(num):
    # Using global to refer to the first_in variable from the main function
    global first_in
    # Retrieving the current display value from f1 and storing it in x
    x = var.get()
    # If it's the first button press, update the default '0' to the entered number
    if first_in:
        # Marking as not the first input anymore
        first_in = False
        # Update the '0' to the entered number
        x = num
    # If num is an operator, add spaces around it for easy calculation later
    elif num == '+' or num == '*' or num == '/' or (num == '-' and x[-1] != ' '):
        x = x + ' ' + num + ' '
    # For regular number inputs, append the number to x
    else:
        x = x + num
    # Update the display on f1
    var.set(x)

    return

# Clear the current display and reset to default (0)
def Clear():
    global first_in
    # Resetting first_in to True
    first_in = True
    # Resetting the display on f1 to '0'
    var.set('0')

    return

# Calculate the result
def Calculate():
    # Split the f1 display string into three parts: number, operator, number
    temp = var.get().split(' ')
    # Using if-elif to categorize the operator and perform the calculation
    if temp[1] == '+':
        ans = int(temp[0]) + int(temp[2])
    elif temp[1] == '-':
        ans = int(temp[0]) - int(temp[2])
    elif temp[1] == '*':
        ans = int(temp[0]) * int(temp[2])
    elif temp[1] == '/':
        if temp[2] == '0':
            var.set('ERROR !!')
        elif temp[0] == '0':
            var.set('0')
        else:
            ans = int(temp[0]) // int(temp[2])
    var.set(str(ans))
    return

# Main function
if __name__ == '__main__':
    # Using first_in to determine if it's the first input (to handle the default '0')
    first_in = True
    # Create a main window
    window = tk.Tk()
    # Name the main window
    window.title("Lab4")
    # Create two frames in the main window

    # Frame 1
    f1 = tk.Frame(window)
    # Frame 2
    f2 = tk.Frame(window)

    # Position the two frames
    f1.pack()
    f2.pack()

    # var stores the string for display on f1
    var = tk.StringVar()

    # Call SetValue Function to set the default for the calculator
    SetValue()

    # Setting up buttons on frame f2 with their positions and functions
    # Number buttons
    btn0 = tk.Button(f2, text = "0", borderwidth = 5, width = 6, height = 2, command = lambda: Click("0")).grid(column = 0, row = 3)
    btn1 = tk.Button(f2, text = "1", borderwidth = 5, width = 6, height = 2, command = lambda: Click("1")).grid(column = 0, row = 2)
    btn2 = tk.Button(f2, text = "2", borderwidth = 5, width = 6, height = 2, command = lambda: Click("2")).grid(column = 1, row = 2)
    btn3 = tk.Button(f2, text = "3", borderwidth = 5, width = 6, height = 2, command = lambda: Click("3")).grid(column = 2, row = 2)
    btn4 = tk.Button(f2, text = "4", borderwidth = 5, width = 6, height = 2, command = lambda: Click("4")).grid(column = 0, row = 1)
    btn5 = tk.Button(f2, text = "5", borderwidth = 5, width = 6, height = 2, command = lambda: Click("5")).grid(column = 1, row = 1)
    btn6 = tk.Button(f2, text = "6", borderwidth = 5, width = 6, height = 2, command = lambda: Click("6")).grid(column = 2, row = 1)
    btn7 = tk.Button(f2, text = "7", borderwidth = 5, width = 6, height = 2, command = lambda: Click("7")).grid(column = 0, row = 0)
    btn8 = tk.Button(f2, text = "8", borderwidth = 5, width = 6, height = 2, command = lambda: Click("8")).grid(column = 1, row = 0)
    btn9 = tk.Button(f2, text = "9", borderwidth = 5, width = 6, height = 2, command = lambda: Click("9")).grid(column = 2, row = 0)
    # add
    btadd = tk.Button(f2, text = "+", borderwidth = 5, width = 6, height = 2, command = lambda: Click("+")).grid(column = 3, row = 2)
    # minus
    btsub = tk.Button(f2, text = "-", borderwidth = 5, width = 6, height = 2, command = lambda: Click("-")).grid(column = 3, row = 1)
    # multiply
    btmul = tk.Button(f2, text = "*", borderwidth = 5, width = 6, height = 2, command = lambda: Click("*")).grid(column = 3, row = 0)
    # divide
    btdiv = tk.Button(f2, text = "/", borderwidth = 5, width = 6, height = 2, command = lambda: Click("/")).grid(column = 3, row = 3)
    # equal
    btequal = tk.Button(f2, text = "=", borderwidth = 5, width = 6, height = 2, command = lambda: Calculate()).grid(column = 2, row = 3)
    # clear
    btclear = tk.Button(f2, text = "c", borderwidth = 5, width = 6, height = 2, command = lambda: Clear()).grid(column = 1, row = 3)
    # Start the Tkinter event loop
    window.mainloop()
    