import tkinter as tk
from tkinter import messagebox
from PIL import Image,ImageTk
import pickle

def login() :
    entry_usr = var1.get()
    entry_pwd = var2.get()
    try:
        try:
            with open('user_info.pickle','rb') as f:
                user_info = pickle.load(f)
        except EOFError:
            user_info = {}
    except FileNotFoundError:
        user_info = {}
    if entry_usr in user_info:
        if entry_pwd ==  user_info[entry_usr]:
            tk.messagebox.showinfo(title = 'login',message = '成功登入')
        else:
            tk.messagebox.showinfo(title = 'login',message = '密碼錯誤')
    else:
        sign_u = tk.messagebox.askyesno(title = 'Warning',message = 'Do you want to create an account by your input ?')
        if sign_u :
            with open ('user_info.pickle','wb') as f:
                user_info = {entry_usr: entry_pwd}
                pickle.dump(user_info,f)
def sign_up():
    window2 = tk.Toplevel(window)
    label3 = tk.Label(window2, text = 'User :').grid(column = 0, row = 0)
    label4 = tk.Label(window2, text = 'Password :').grid(column = 0, row = 1)
    label5 = tk.Label(window2, text = 'User :').grid(column = 0, row = 2)
    entry3 = tk.Entry(window2,textvariable=var3).grid(column = 1, row = 0)
    entry4 = tk.Entry(window2,textvariable=var4,show='*').grid(column = 1, row = 1)
    entry5 = tk.Entry(window2,textvariable=var5,show='*').grid(column = 1, row = 2)
    signu = tk.Button(window2, text = "sign up", borderwidth = 5, width = 6, height = 2, command = lambda: sign_up2()).grid(column = 2, row = 3)
    def sign_up2():
        entry2_usr = var3.get()
        entry2_pwd = var4.get()
        entry2_check = var5.get()
        try:
            try:
                with open('user_info.pickle','rb') as f:
                    user_info = pickle.load(f)
            except EOFError:
                user_info = {}
        except FileNotFoundError:
            user_info = {}

        if entry2_usr in user_info:
            tk.messagebox.showinfo(title = 'Warning',message = '帳號已被註冊')
        elif entry2_pwd != entry2_check:
            tk.messagebox.showinfo(title = 'Warning',message = '輸入密碼與確認密碼不相同')
        else:
            with open('user_info.pickle','wb') as f:
                user_info = {entry2_usr:entry2_pwd}
                pickle.dump(user_info,f)
                window2.destroy()

window = tk.Tk()
window.title('Lab5')
window.geometry('400x400')
f1 = tk.Frame(window)
f2 = tk.Frame(window)
f1.pack()
f2.pack()
var1 = tk.StringVar()
var2 = tk.StringVar()
var3 = tk.StringVar()
var4 = tk.StringVar()
var5 = tk.StringVar()
label1 = tk.Label(f2, text = 'User: ').grid(column = 0, row = 0)
#label1.pack()
label2 = tk.Label(f2, text = 'Password: ').grid(column = 0, row = 1)
#label2.pack()
entry1 = tk.Entry(f2,textvariable=var1).grid(column = 1, row = 0)
entry2 = tk.Entry(f2,textvariable=var2,show='*').grid(column = 1, row = 1)
image1 = ImageTk.PhotoImage(Image.open('1.jpg').resize((200,200)))
im = tk.Label(f1,image=image1)
im.pack()
log = tk.Button(f2, text = "login", borderwidth = 5, width = 6, height = 2, command = lambda: login()).grid(column = 0, row = 3)
sign = tk.Button(f2, text = "sign up", borderwidth = 5, width = 6, height = 2, command = lambda: sign_up()).grid(column = 2, row = 3)
window.mainloop()