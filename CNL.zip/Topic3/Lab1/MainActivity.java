package com.example.app110511184;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    // Declare parameters
    TextView showtext; // Define TextView to display text
    TextView text2;    // Define another TextView
    Button demobutton; // Define a Button
    Button button2;    // Define another Button
    Button button3;    // Define another Button
    Button button4;    // Define another Button
    EditText Name;     // Define EditText for text input
    int size;          // Declare a variable for size

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Set the layout for this activity

        // Connecting to the UI elements in the XML file by their IDs
        showtext = (TextView)findViewById(R.id.showtext);
        text2 = (TextView)findViewById(R.id.text2);
        demobutton = (Button)findViewById(R.id.demobutton);
        button2 = (Button)findViewById(R.id.button2);
        button3 = (Button)findViewById(R.id.button3);
        button4 = (Button)findViewById(R.id.button4);
        Name = (EditText)findViewById(R.id.Name);

        // Set an OnClickListener for the demobutton. When clicked, it will display "Pass!"
        // and continuously increase the font size
        demobutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showtext.setText("Pass!");
                size = (int)showtext.getTextSize() + 5;
                showtext.setTextSize(TypedValue.COMPLEX_UNIT_PX, size);
            }
        });

        // Set an OnClickListener for button2. When clicked, it will display "Android Lab1 demo"
        // and continuously decrease the font size
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showtext.setText("Android Lab1 demo");
                size = (int)showtext.getTextSize() - 5;
                showtext.setTextSize(TypedValue.COMPLEX_UNIT_PX, size);
            }
        });

        // Set an OnClickListener for button3. When clicked, it displays a welcome message
        // including the name entered in the Name EditText
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text2.setText("Welcome to Android, " + Name.getText().toString() + "!");
            }
        });

        // Set an OnClickListener for button4. When clicked, it will display "Hello World!"
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text2.setText("Hello World!");
            }
        });
    }
}
